import glob
import os
import calendar
import datetime
from pmonitor import PMonitor

__author__ = 'olafd'

#sensors = ['MERIS','VGT']
#sensors = ['MERIS']
sensors = ['VGT']
#year = sys.argv[1]   # in [1997, 2010]
#years = ['2006']    #test  
years = ['2005']    #test  
#years = ['2004','2005']    #test  
#allMonthsMeris = ['01', '02', '03']
#allMonthsMeris = ['04', '05', '06']
#allMonthsMeris = ['04', '05', '06']
#allMonthsMeris = ['10', '11', '12']
#allMonthsMeris = ['04', '05', '06', '07', '08', '09', '10', '11', '12']
#allMonthsMeris = ['05', '06', '07', '08', '09', '10', '11']
allMonthsMeris = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
#allMonthsVGT = ['10', '11', '12']  # data at CEMS from Vito is stored like this
#allMonthsVGT = ['1', '2', '3']  # data at CEMS from Vito is stored like this
#allMonthsVGT = ['4', '5', '6']  # data at CEMS from Vito is stored like this
#allMonthsVGT = ['7', '8', '9']  # data at CEMS from Vito is stored like this
allMonthsVGT = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']  # data at CEMS from Vito is stored like this
#allMonthsMeris = ['01']
#allMonthsVGT = ['1']

#################################################################
def getMonth(year):
    if sensor == 'MERIS':
        return getMonthMeris(year)
    if sensor == 'VGT':
        return getMonthVgt(year)
    return []

def getMonthVgt(year):
    if year == '2002':
        return ['6', '7', '8', '9', '10', '11', '12']
    if year == '2012':
        return ['1', '2', '3', '4']
    return allMonthsVGT

def getMonthMeris(year):
    if year == '2002':
        return ['06', '07', '08', '09', '10', '11', '12']
    if year == '2012':
        return ['01', '02', '03', '04']
    return allMonthsMeris

def getNumMonthDays(year, month_index):
    if month_index == 2:
        if calendar.isleap(int(year)):      
            return 29 
        else:
            return 28
    elif month_index == 4 or month_index == 6 or month_index == 9 or month_index == 11:
        return 30
    else:
        #return 3  # test!!
        return 31

#################################################################

######################## SDR orbits --> tiles: ###########################

gaRootDir = '/group_workspaces/cems2/qa4ecv/vol1/olafd/GlobAlbedoTest'
beamDir = '/group_workspaces/cems2/qa4ecv/vol4/software/beam-5.0.1'

inputs = []
for year in years:
    for sensor in sensors:
        for month in getMonth(year):
    	    sdrOrbitDir = gaRootDir + '/SDR_orbits/' + sensor + '/' + year + '/' + month 
            if os.path.exists(sdrOrbitDir):
                sdrFiles = os.listdir(sdrOrbitDir)
                if len(sdrFiles) > 0:
                    for index in range(0, len(sdrFiles)):
                        if sdrFiles[index].endswith(".nc") or sdrFiles[index].endswith(".nc.gz"):
                            inputs.append(sdrOrbitDir + '/' + sdrFiles[index])

#print 'inputs: ', inputs
m = PMonitor(inputs, 
             request='ga-l2-sdr-tiles',
             logdir='log', 
             hosts=[('localhost',192)],
             types=[('ga-l2-sdr-tiles-step.sh',192)])

for year in years:
    for sensor in sensors:
        sdrTileDir = gaRootDir + '/SDR/' + sensor + '/' + year 
        for month in getMonth(year):
            sdrOrbitDir = gaRootDir + '/SDR_orbits/' + sensor + '/' + year + '/' + month 
            if os.path.exists(sdrOrbitDir):
                sdrFiles = os.listdir(sdrOrbitDir)
                if len(sdrFiles) > 0:
                   for index in range(0, len(sdrFiles)):
		       sdrOrbitFilePath = sdrOrbitDir + '/' + sdrFiles[index]
                       #print 'index, sdrOrbitFilePath', index, ', ', sdrOrbitFilePath
                       m.execute('ga-l2-sdr-tiles-step.sh', [sdrOrbitFilePath], [sdrTileDir], parameters=[sdrOrbitFilePath,sdrFiles[index],sdrTileDir,sensor,gaRootDir,beamDir])

m.wait_for_completion()

