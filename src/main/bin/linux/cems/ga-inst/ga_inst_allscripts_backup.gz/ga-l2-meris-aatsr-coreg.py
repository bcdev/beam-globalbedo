import glob
import os
import calendar
import datetime
from pmonitor import PMonitor

__author__ = 'olafd'

years = ['2005']    #test  
allMonths = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']

#################################################################

def getMonth(year):
    if year == '2002':
        return ['06', '07', '08', '09', '10', '11', '12']
    if year == '2012':
        return ['01', '02', '03', '04']
    return allMonths

def getNumMonthDays(year, month_index):
    if month_index == 2:
        if calendar.isleap(int(year)):
            return 29
        else:
            return 28
    elif month_index == 4 or month_index == 6 or month_index == 9 or month_index == 11:
        return 30
    else:
        #return 3  # test!!
        return 31

######################## L1b --> BBDR: ###########################

#gaRootDir = '/group_workspaces/cems2/qa4ecv/vol1/olafd/GlobAlbedoTest'
gaRootDir = '/group_workspaces/cems2/qa4ecv/vol1/olafd/GaTestData'

beamDir = '/group_workspaces/cems/globalalbedo/soft/beam-5.0.1'

inputs = ['dummy']
m = PMonitor(inputs, 
             request='ga-l2-meris-aatsr-coreg',
             logdir='log', 
             hosts=[('localhost',192)],
             types=[('ga-l2-meris-aatsr-coreg-step.sh',192)])

for year in years:
    for month in getMonth(year):
        for day in range(1, getNumMonthDays(year, int(month))+1):
            merisL1bDir = gaRootDir + '/L1b/MERIS/' + year + '/' + month + '/' + str(day).zfill(2)
            aatsrL1bDir = gaRootDir + '/L1b/AATSR/' + year + '/' + month + '/' + str(day).zfill(2)

            if os.path.exists(merisL1bDir) and os.path.exists(aatsrL1bDir):

                merisL1bFiles = os.listdir(merisL1bDir)
                aatsrL1bFiles = os.listdir(aatsrL1bDir)
                if len(merisL1bFiles) > 0 and len(aatsrL1bFiles) > 0:
                    collocDir = gaRootDir + '/COLLOC/' + '/' + year + '/' + month + '/' + str(day).zfill(2)
                    print 'merisL1bDir: ', merisL1bDir 
                    print 'aatsrL1bDir: ', aatsrL1bDir 
                    print 'collocDir: ', collocDir 
                    m.execute('ga-l2-meris-aatsr-coreg-step.sh', ['dummy'], [collocDir], parameters=[merisL1bDir,aatsrL1bDir,year,month,str(day).zfill(2),gaRootDir,beamDir])

m.wait_for_completion()

